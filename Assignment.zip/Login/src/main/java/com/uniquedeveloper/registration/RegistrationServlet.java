package com.uniquedeveloper.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.xdevapi.Statement;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Statement stmt=null;
	 public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException 
     {  
        PrintWriter out = res.getWriter();  
        res.setContentType("text/html");  
        out.println("<html><body>");  
        try 
        {  
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");  
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306	/youtube?useSSl=false","root","Aniket@123");   
            stmt = (Statement) con.createStatement();  
            ResultSet rs = ((java.sql.Statement) stmt).executeQuery("select * from users");  
            out.println("<table border=1 width=50% height=50%>");  
            out.println("<tr><th>ufirst_name</th><th>ulast_name</th><th>ustreet</th><th>uaddress</th><th>ucity</th><th>ustate</th><th>uemail</th><th>umobile</th><tr>");  
            while (rs.next()) 
            {  
                String a = rs.getString("ufirst_name");  
                String b = rs.getString("ulast_name");  
                String c = rs.getString("ustreet");
                String d = rs.getString("uaddress");
                String e = rs.getString("ucity");
                String f = rs.getString("ustate");
                String g = rs.getString("uemail");
                String h = rs.getString("umobile");
                out.println("<tr><td>" + a + "</td><td>" + b + "</td><td>" + c + "</td></tr>"+d+"</td></tr>"+e+"</td></tr>"+f+"</td></tr>"+g+"</td></tr>"+h+"</td></tr>");   
            }  
            out.println("</table>");  
            out.println("</html></body>");  
            con.close();  
           }  
            catch (Exception e) 
           {  
            out.println("error");  
        }  
    }  
       
     
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String ufirst_name = request.getParameter("first_name");
	    String ulast_name = request.getParameter("last_name");
	    String ustreet = request.getParameter("street");
	    String uaddress = request.getParameter("address");
	    String ucity = request.getParameter("city");
	    String ustate = request.getParameter("state");
	    String uemail = request.getParameter("email");	
	    
	    System.out.println(ufirst_name);

	    String umobile = request.getParameter("contact");	
	    RequestDispatcher dispatcher=null;
	   
	    Connection con=null;
	    try {
	    	Class.forName("com.mysql.cj.jdbc.Driver");
	    	con=DriverManager.getConnection("jdbc:mysql://localhost:3306	/youtube?useSSl=false","root","Aniket@123");
	    	PreparedStatement pst = con.prepareStatement("insert into users(ufirst_name,ulast_name,ustreet,uaddress,ucity,ustate,uemail,umobile) values(?,?,?,?,?,?,?,?) ");
	    	pst.setString(1, ufirst_name);
	    	pst.setString(1, ulast_name);
	    	pst.setString(1, ustreet);
	    	pst.setString(1, uaddress);
	    	pst.setString(1, ucity);
	    	pst.setString(1, ustate);
	    	pst.setString(1, uemail);
	    	pst.setString(1, umobile);
	    	
	    	ResultSet rs = pst.executeQuery(); 
	    	int rowCount = pst.executeUpdate();
	    	dispatcher = request.getRequestDispatcher("registration.jsp");
	    	if(rowCount > 0)
	    	{
	    		request.setAttribute("status","success");
	    	}
	    	else {
	    		request.setAttribute("status","failed");
	    	}
	    	dispatcher.forward(request,response);
	    
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	    /*finally
	    {
	       try {   	
	    	   con.close();
	       }
	       catch(SQLException e)
	       {
	    	   e.printStackTrace();
	       }
        }*/
	}

}
